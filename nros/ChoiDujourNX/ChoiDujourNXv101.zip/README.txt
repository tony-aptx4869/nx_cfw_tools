ChoiDujourNX 1.0.1 (released on 02.08.2018)
Copyright (C) 2018 Rajko Stojadinovic. All rights reserved.
For further licensing information, read the file LICENSE.txt in this package.

DESCRIPTION
    This is an automated firmware package installer meant to be run on the Nintendo Switch.

INSTALLATION
    Copy the ChoiDujourNX.nro file to a folder your hbmenu scans (the switch folder on your microSD)

USE
    After running the homebrew on your Nintendo Switch, simply select a folder containing system content files, 
    and it will analyze and allow you to install the firmwares contained within, via a user-friendly touchscreen GUI.

For updates go to https://switchtools.sshnuke.net
Redistribution of copies of this software publically is not allowed.
To refer others on where to download this software, use the above URL.
If you have acquired this software from a location other than the one listed above,
you should DELETE it and never run it on your hardware, as it's legitimacy may be suspect.